# goal --> process csv to sqlite

# iterate over every column name
# echo the full column name into separate reference file that will end up being a reference dictionary
# replace each full column name with a unique sequential integer



# if csv-to-sqlite not installed
# pip install csv-to-sqlite

python3
File_object = open(r"File_Name","Access_Mode")